# Universal Bushy Leaves
A Resource Pack adding bushier leaves to minecraft everwhere you look, designed with universal compatibility in mind.
https://discord.gg/H9V6FuVGfT